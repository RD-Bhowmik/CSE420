#include "symbol_info.h"

class scope_table
{
private:
    int bucket_count;
    int unique_id;
    scope_table *parent_scope = NULL;
    vector<list<symbol_info *>> table;

    int hash_function(string name)
    {
        unsigned long hash = 5381;
        for (int i = 0; i < name.length(); i++) {
            hash = ((hash << 5) + hash) + name[i]; 
        }
        return hash % bucket_count;
    }

public:
    scope_table();
    scope_table(int bucket_count, int unique_id, scope_table *parent_scope);
    scope_table *get_parent_scope();
    int get_unique_id();
    symbol_info *lookup_in_scope(symbol_info* symbol);
    bool insert_in_scope(symbol_info* symbol);
    bool delete_from_scope(symbol_info* symbol);
    void print_scope_table(ofstream& outlog);
    ~scope_table();
};

scope_table::scope_table()
{
    this->bucket_count = 7; 
    this->unique_id = 1;
    this->parent_scope = NULL;
    this->table.resize(bucket_count);
}

scope_table::scope_table(int bucket_count, int unique_id, scope_table *parent_scope)
{
    this->bucket_count = bucket_count;
    this->unique_id = unique_id;
    this->parent_scope = parent_scope;
    this->table.resize(bucket_count);
}

scope_table *scope_table::get_parent_scope()
{
    return parent_scope;
}

int scope_table::get_unique_id()
{
    return unique_id;
}

symbol_info *scope_table::lookup_in_scope(symbol_info* symbol)
{
    int bucket_index = hash_function(symbol->get_name());
    
    for (auto it = table[bucket_index].begin(); it != table[bucket_index].end(); it++)
    {
        if ((*it)->get_name() == symbol->get_name())
        {
            return *it;
        }
    }
    return NULL; 
}

bool scope_table::insert_in_scope(symbol_info* symbol)
{
    if (lookup_in_scope(symbol) != NULL)
    {
        return false; 
    }
    
    int bucket_index = hash_function(symbol->get_name());
    table[bucket_index].push_back(symbol);
    return true; 
}

bool scope_table::delete_from_scope(symbol_info* symbol)
{
    int bucket_index = hash_function(symbol->get_name());
    
    for (auto it = table[bucket_index].begin(); it != table[bucket_index].end(); it++)
    {
        if ((*it)->get_name() == symbol->get_name())
        {
            delete *it; 
            table[bucket_index].erase(it);
            return true; 
        }
    }
    return false; 
}

void scope_table::print_scope_table(ofstream& outlog)
{
    outlog << "ScopeTable # " + to_string(unique_id) << endl;

    for (int i = 0; i < bucket_count; i++)
    {
        if (!table[i].empty())
        {
            outlog << i << " --> ";
            bool first = true;
            for (auto symbol : table[i])
            {
                if (!first) outlog << " ";
                
                outlog << "< " << symbol->get_name();
                
                if (symbol->is_function())
                {
                    outlog << " : FUNCTION, " << symbol->get_return_type();
                }
                else if (symbol->is_array())
                {
                    outlog << " : " << symbol->get_data_type() << ", " << symbol->get_array_size();
                }
                else if (symbol->is_variable())
                {
                    outlog << " : " << symbol->get_data_type();
                }
                else
                {
                    outlog << " : " << symbol->get_type();
                }
                
                outlog << " >";
                first = false;
            }
            outlog << endl;
        }
    }
    outlog << endl;
}

scope_table::~scope_table()
{
    for (int i = 0; i < bucket_count; i++)
    {
        for (auto symbol : table[i])
        {
            delete symbol;
        }
        table[i].clear();
    }
}