#include<bits/stdc++.h>
using namespace std;

class symbol_info
{
private:
    string name;
    string type;

    string symbol_category;
    
    string data_type;
    
    int array_size;
    
    string return_type;
    int param_count;
    vector<string> param_types;
    vector<string> param_names;

public:
    symbol_info(string name, string type)
    {
        this->name = name;
        this->type = type;
        this->symbol_category = "";
        this->data_type = "";
        this->array_size = -1;
        this->return_type = "";
        this->param_count = 0;
    }
    
    string get_name()
    {
        return name;
    }
    
    string get_type()
    {
        return type;
    }
    
    void set_name(string name)
    {
        this->name = name;
    }
    
    void set_type(string type)
    {
        this->type = type;
    }
    
    string get_symbol_category()
    {
        return symbol_category;
    }
    
    void set_symbol_category(string category)
    {
        this->symbol_category = category;
    }
    
    string get_data_type()
    {
        return data_type;
    }
    
    void set_data_type(string dtype)
    {
        this->data_type = dtype;
    }
    
    int get_array_size()
    {
        return array_size;
    }
    
    void set_array_size(int size)
    {
        this->array_size = size;
    }
    
    string get_return_type()
    {
        return return_type;
    }
    
    void set_return_type(string ret_type)
    {
        this->return_type = ret_type;
    }
    
    int get_param_count()
    {
        return param_count;
    }
    
    void set_param_count(int count)
    {
        this->param_count = count;
    }
    
    vector<string> get_param_types()
    {
        return param_types;
    }
    
    void set_param_types(vector<string> types)
    {
        this->param_types = types;
        this->param_count = types.size();
    }
    
    void add_param_type(string param_type)
    {
        this->param_types.push_back(param_type);
        this->param_count++;
    }
    
    vector<string> get_param_names()
    {
        return param_names;
    }
    
    void set_param_names(vector<string> names)
    {
        this->param_names = names;
    }
    
    void add_param_name(string param_name)
    {
        this->param_names.push_back(param_name);
    }
    
    bool is_variable()
    {
        return symbol_category == "variable";
    }
    
    bool is_array()
    {
        return symbol_category == "array";
    }
    
    bool is_function()
    {
        return symbol_category == "function";
    }
    
    string getname()
    {
        return name;
    }

    ~symbol_info()
    {
        param_types.clear();
        param_names.clear();
    }
};