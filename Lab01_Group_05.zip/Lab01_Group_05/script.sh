#!/bin/bash


INPUT_FILE=${1:-input2.txt}
LOG_FILE=${2:-24141083_24141100_log2.txt}

yacc -d -y --debug --verbose 24141083_24141100.y
echo 'Generated the parser C file as well the header file'

g++ -w -c -o y.o y.tab.c
echo 'Generated the parser object file'

flex 24141083_24141100.l
echo 'Generated the scanner C file'

# g++ -fpermissive -w -c -o l.o lex.yy.c
# if the above command doesn't work try 
g++ -fpermissive -w -c -o l.o lex.yy.c
echo 'Generated the scanner object file'

g++ y.o l.o -o compiler.exe
echo 'All ready, running'

./compiler.exe $INPUT_FILE $LOG_FILE
echo "compilation done"

echo "log output"
cat $LOG_FILE 