%{

#include "symbol_table.h"

#define YYSTYPE symbol_info*

extern FILE *yyin;
int yyparse(void);
int yylex(void);
extern YYSTYPE yylval;

// Create global symbol table with 11 buckets
symbol_table* symtab;

int lines = 1;

ofstream outlog;
ofstream outerr;
int error_count = 0;

// Variables to store current information during parsing
string current_type = "";
vector<string> var_list;
string func_name = "";
string func_return_type = "";
vector<string> param_types;
vector<string> param_names;

void yyerror(char *s)
{
	outlog<<"At line "<<lines<<" "<<s<<endl<<endl;

    // Clear temporary variables on error
    current_type = "";
    var_list.clear();
    func_name = "";
    func_return_type = "";
    param_types.clear();
    param_names.clear();
}

%}

%token IF ELSE FOR WHILE DO BREAK INT CHAR FLOAT DOUBLE VOID RETURN SWITCH CASE DEFAULT CONTINUE PRINTLN ADDOP MULOP INCOP DECOP RELOP ASSIGNOP LOGICOP NOT LPAREN RPAREN LCURL RCURL LTHIRD RTHIRD COMMA SEMICOLON CONST_INT CONST_FLOAT ID

%nonassoc LOWER_THAN_ELSE
%nonassoc ELSE

%%

start : program
	{
		outlog<<"At line no: "<<lines<<" start : program "<<endl<<endl;
		outlog<<"Symbol Table"<<endl<<endl;
		
		// Print the final symbol table
		symtab->print_all_scopes(outlog);
	}
	;

program : program unit
	{
		outlog<<"At line no: "<<lines<<" program : program unit "<<endl<<endl;
		outlog<<$1->getname()+"\n"+$2->getname()<<endl<<endl;
		
		$$ = new symbol_info($1->getname()+"\n"+$2->getname(),"program");
	}
	| unit
	{
		outlog<<"At line no: "<<lines<<" program : unit "<<endl<<endl;
		outlog<<$1->getname()<<endl<<endl;
		
		$$ = new symbol_info($1->getname(),"program");
	}
	;

unit : var_declaration
	 {
		outlog<<"At line no: "<<lines<<" unit : var_declaration "<<endl<<endl;
		outlog<<$1->getname()<<endl<<endl;
		
		$$ = new symbol_info($1->getname(),"unit");
	 }
     | func_definition
     {
		outlog<<"At line no: "<<lines<<" unit : func_definition "<<endl<<endl;
		outlog<<$1->getname()<<endl<<endl;
		
		$$ = new symbol_info($1->getname(),"unit");
	 }
     ;

func_definition : type_specifier ID LPAREN parameter_list RPAREN compound_statement
		{	
			outlog<<"At line no: "<<lines<<" func_definition : type_specifier ID LPAREN parameter_list RPAREN compound_statement "<<endl<<endl;
			outlog<<$1->getname()<<" "<<$2->getname()<<"("+$4->getname()+")\n"<<$6->getname()<<endl<<endl;
			
			$$ = new symbol_info($1->getname()+" "+$2->getname()+"("+$4->getname()+")\n"+$6->getname(),"func_def");	
			
			// Create function symbol and insert into symbol table
			symbol_info* func_symbol = new symbol_info($2->getname(), "ID");
			func_symbol->set_symbol_category("function");
			func_symbol->set_return_type($1->getname());
			func_symbol->set_param_types(param_types);
			func_symbol->set_param_names(param_names);
			
			// Check for duplicate parameter names
			string func_name = $2->getname();
			for (int i = 0; i < param_names.size(); i++) {
				for (int j = i + 1; j < param_names.size(); j++) {
					if (param_names[i] == param_names[j] && param_names[i] != "") {
						outerr << "At line no: " << lines << " Multiple declaration of variable " << param_names[i] << " in parameter of " << func_name << endl << endl;
						error_count++;
					}
				}
			}
			
			bool inserted = symtab->insert(func_symbol);
			if (!inserted) {
				outerr << "At line no: " << lines << " Multiple declaration of function " << $2->getname() << endl << endl;
				error_count++;
				delete func_symbol;
			}
			
			// Clear parameter lists for next function
			param_types.clear();
			param_names.clear();
		}
		| type_specifier ID LPAREN RPAREN compound_statement
		{
			
			outlog<<"At line no: "<<lines<<" func_definition : type_specifier ID LPAREN RPAREN compound_statement "<<endl<<endl;
			outlog<<$1->getname()<<" "<<$2->getname()<<"()\n"<<$5->getname()<<endl<<endl;
			
			$$ = new symbol_info($1->getname()+" "+$2->getname()+"()\n"+$5->getname(),"func_def");	
			
			// Create function symbol and insert into symbol table
			symbol_info* func_symbol = new symbol_info($2->getname(), "ID");
			func_symbol->set_symbol_category("function");
			func_symbol->set_return_type($1->getname());
			// No parameters for this function
			
			bool inserted = symtab->insert(func_symbol);
			if (!inserted) {
				outerr << "At line no: " << lines << " Multiple declaration of function " << $2->getname() << endl << endl;
				error_count++;
				delete func_symbol;
			}
		}
 		;

parameter_list : parameter_list COMMA type_specifier ID
		{
			outlog<<"At line no: "<<lines<<" parameter_list : parameter_list COMMA type_specifier ID "<<endl<<endl;
			outlog<<$1->getname()<<","<<$3->getname()<<" "<<$4->getname()<<endl<<endl;
					
			$$ = new symbol_info($1->getname()+","+$3->getname()+" "+$4->getname(),"param_list");
			
            // Store parameter information
            param_types.push_back($3->getname());
            param_names.push_back($4->getname());
		}
		| parameter_list COMMA type_specifier
		{
			outlog<<"At line no: "<<lines<<" parameter_list : parameter_list COMMA type_specifier "<<endl<<endl;
			outlog<<$1->getname()<<","<<$3->getname()<<endl<<endl;
			
			$$ = new symbol_info($1->getname()+","+$3->getname(),"param_list");
			
            // Store parameter type without name
            param_types.push_back($3->getname());
            param_names.push_back(""); // No name for this parameter
		}
 		| type_specifier ID
 		{
			outlog<<"At line no: "<<lines<<" parameter_list : type_specifier ID "<<endl<<endl;
			outlog<<$1->getname()<<" "<<$2->getname()<<endl<<endl;
			
			$$ = new symbol_info($1->getname()+" "+$2->getname(),"param_list");
			
            // Store first parameter information
            param_types.clear(); // Clear for new parameter list
            param_names.clear();
            param_types.push_back($1->getname());
            param_names.push_back($2->getname());
		}
		| type_specifier
		{
			outlog<<"At line no: "<<lines<<" parameter_list : type_specifier "<<endl<<endl;
			outlog<<$1->getname()<<endl<<endl;
			
			$$ = new symbol_info($1->getname(),"param_list");
			
            // Store first parameter type without name
            param_types.clear(); // Clear for new parameter list
            param_names.clear();
            param_types.push_back($1->getname());
            param_names.push_back(""); // No name for this parameter
		}
 		;

compound_statement : LCURL { 
				// Enter new scope
				symtab->enter_scope();
				outlog << "New ScopeTable with ID " << symtab->get_current_scope_id() << " created" << endl << endl;
				
				// Insert function parameters if any
				for (int i = 0; i < param_names.size(); i++) {
					if (param_names[i] != "") {
						symbol_info* param_symbol = new symbol_info(param_names[i], "ID");
						param_symbol->set_symbol_category("variable");
						param_symbol->set_data_type(param_types[i]);
						
						bool inserted = symtab->insert(param_symbol);
						if (!inserted) {
							delete param_symbol;
						}
					}
				}
			} statements RCURL
			{ 
 		    	outlog<<"At line no: "<<lines<<" compound_statement : LCURL statements RCURL "<<endl<<endl;
				outlog<<"{\n"+$3->getname()+"\n}"<<endl<<endl;
				
				$$ = new symbol_info("{\n"+$3->getname()+"\n}","comp_stmnt");
				
                // Print symbol table and exit scope
                symtab->print_all_scopes(outlog);
                outlog << "Scopetable with ID " << symtab->get_current_scope_id() << " removed" << endl << endl;
                symtab->exit_scope();
 		    }
 		    | LCURL { 
				// Enter new scope
				symtab->enter_scope();
				outlog << "New ScopeTable with ID " << symtab->get_current_scope_id() << " created" << endl << endl;
				
				// Insert function parameters if any
				for (int i = 0; i < param_names.size(); i++) {
					if (param_names[i] != "") {
						symbol_info* param_symbol = new symbol_info(param_names[i], "ID");
						param_symbol->set_symbol_category("variable");
						param_symbol->set_data_type(param_types[i]);
						
						bool inserted = symtab->insert(param_symbol);
						if (!inserted) {
							delete param_symbol;
						}
					}
				}
			} RCURL
 		    { 
 		    	outlog<<"At line no: "<<lines<<" compound_statement : LCURL RCURL "<<endl<<endl;
				outlog<<"{\n}"<<endl<<endl;
				
				$$ = new symbol_info("{\n}","comp_stmnt");
				
				// Print symbol table and exit scope
                outlog << "Scopetable with ID " << symtab->get_current_scope_id() << " removed" << endl;
                symtab->print_all_scopes(outlog);
                symtab->exit_scope();
 		    }
 		    ;
 		    
var_declaration : type_specifier declaration_list SEMICOLON
		 {
			outlog<<"At line no: "<<lines<<" var_declaration : type_specifier declaration_list SEMICOLON "<<endl<<endl;
			outlog<<$1->getname()<<" "<<$2->getname()<<";"<<endl<<endl;
			
			$$ = new symbol_info($1->getname()+" "+$2->getname()+";","var_dec");
			
			// Get the current type and insert variables into symbol table
			string curr_type = $1->getname();
			
			// Check for void type
			if (curr_type == "void") {
				outerr << "At line no: " << lines << " variable type can not be void " << endl << endl;
				error_count++;
			}
			
			for (const auto& var_name : var_list) {
				// Extract variable name and array size if it's an array
				size_t bracket_pos = var_name.find('[');
				if (bracket_pos != string::npos) {
					// It's an array
					string name = var_name.substr(0, bracket_pos);
					string size_str = var_name.substr(bracket_pos + 1);
					size_str = size_str.substr(0, size_str.find(']'));
					
					symbol_info* var_symbol = new symbol_info(name, "ID");
					var_symbol->set_symbol_category("array");
					var_symbol->set_data_type(curr_type);
					var_symbol->set_array_size(stoi(size_str));
					
					bool inserted = symtab->insert(var_symbol);
					if (!inserted) {
						outerr << "At line no: " << lines << " Multiple declaration of variable " << name << endl << endl;
						outlog << "At line no: " << lines << " Multiple declaration of variable " << name << endl << endl;
						error_count++;
						delete var_symbol;
					}
				} else {
					// It's a regular variable
					symbol_info* var_symbol = new symbol_info(var_name, "ID");
					var_symbol->set_symbol_category("variable");
					var_symbol->set_data_type(curr_type);
					
					bool inserted = symtab->insert(var_symbol);
					if (!inserted) {
						outerr << "At line no: " << lines << " Multiple declaration of variable " << var_name << endl << endl;
						outlog << "At line no: " << lines << " Multiple declaration of variable " << var_name << endl << endl;
						error_count++;
						delete var_symbol;
					}
				}
			}
			
			// Clear the variable list for next declaration
			var_list.clear();
		 }
 		 ;

type_specifier : INT
		{
			outlog<<"At line no: "<<lines<<" type_specifier : INT "<<endl<<endl;
			outlog<<"int"<<endl<<endl;
			
			$$ = new symbol_info("int","type");
	    }
 		| FLOAT
 		{
			outlog<<"At line no: "<<lines<<" type_specifier : FLOAT "<<endl<<endl;
			outlog<<"float"<<endl<<endl;
			
			$$ = new symbol_info("float","type");
	    }
 		| VOID
 		{
			outlog<<"At line no: "<<lines<<" type_specifier : VOID "<<endl<<endl;
			outlog<<"void"<<endl<<endl;
			
			$$ = new symbol_info("void","type");
	    }
 		;

declaration_list : declaration_list COMMA ID
		  {
 		  	outlog<<"At line no: "<<lines<<" declaration_list : declaration_list COMMA ID "<<endl<<endl;
 		  	outlog<<$1->getname()+","<<$3->getname()<<endl<<endl;

            // Add variable name to the list
            var_list.push_back($3->getname());
            
            $$ = new symbol_info($1->getname()+","+$3->getname(),"dec_list");
 		  }
 		  | declaration_list COMMA ID LTHIRD CONST_INT RTHIRD //array after some declaration
 		  {
 		  	outlog<<"At line no: "<<lines<<" declaration_list : declaration_list COMMA ID LTHIRD CONST_INT RTHIRD "<<endl<<endl;
 		  	outlog<<$1->getname()+","<<$3->getname()<<"["<<$5->getname()<<"]"<<endl<<endl;

            // Add array variable name to the list
            var_list.push_back($3->getname() + "[" + $5->getname() + "]");
            
            $$ = new symbol_info($1->getname()+","+$3->getname()+"["+$5->getname()+"]","dec_list");
 		  }
 		  |ID
 		  {
 		  	outlog<<"At line no: "<<lines<<" declaration_list : ID "<<endl<<endl;
			outlog<<$1->getname()<<endl<<endl;

            // Initialize the variable list with first variable
            var_list.clear();
            var_list.push_back($1->getname());
            
            $$ = new symbol_info($1->getname(),"dec_list");
 		  }
 		  | ID LTHIRD CONST_INT RTHIRD //array
 		  {
 		  	outlog<<"At line no: "<<lines<<" declaration_list : ID LTHIRD CONST_INT RTHIRD "<<endl<<endl;
			outlog<<$1->getname()<<"["<<$3->getname()<<"]"<<endl<<endl;

            // Initialize the variable list with first array variable
            var_list.clear();
            var_list.push_back($1->getname() + "[" + $3->getname() + "]");
            
            $$ = new symbol_info($1->getname()+"["+$3->getname()+"]","dec_list");
 		  }
 		  ;
 		  

statements : statement
	   {
	    	outlog<<"At line no: "<<lines<<" statements : statement "<<endl<<endl;
			outlog<<$1->getname()<<endl<<endl;
			
			$$ = new symbol_info($1->getname(),"stmnts");
	   }
	   | statements statement
	   {
	    	outlog<<"At line no: "<<lines<<" statements : statements statement "<<endl<<endl;
			outlog<<$1->getname()<<"\n"<<$2->getname()<<endl<<endl;
			
			$$ = new symbol_info($1->getname()+"\n"+$2->getname(),"stmnts");
	   }
	   ;
	   
statement : var_declaration
	  {
	    	outlog<<"At line no: "<<lines<<" statement : var_declaration "<<endl<<endl;
			outlog<<$1->getname()<<endl<<endl;
			
			$$ = new symbol_info($1->getname(),"stmnt");
	  }
	  | func_definition
	  {
	  		outlog<<"At line no: "<<lines<<" statement : func_definition "<<endl<<endl;
            outlog<<$1->getname()<<endl<<endl;

            $$ = new symbol_info($1->getname(),"stmnt");
	  		
	  }
	  | expression_statement
	  {
	    	outlog<<"At line no: "<<lines<<" statement : expression_statement "<<endl<<endl;
			outlog<<$1->getname()<<endl<<endl;
			
			$$ = new symbol_info($1->getname(),"stmnt");
	  }
	  | compound_statement
	  {
	    	outlog<<"At line no: "<<lines<<" statement : compound_statement "<<endl<<endl;
			outlog<<$1->getname()<<endl<<endl;
			
			$$ = new symbol_info($1->getname(),"stmnt");
	  }
	  | FOR LPAREN expression_statement expression_statement expression RPAREN statement
	  {
	    	outlog<<"At line no: "<<lines<<" statement : FOR LPAREN expression_statement expression_statement expression RPAREN statement "<<endl<<endl;
			outlog<<"for("<<$3->getname()<<$4->getname()<<$5->getname()<<")\n"<<$7->getname()<<endl<<endl;
			
			$$ = new symbol_info("for("+$3->getname()+$4->getname()+$5->getname()+")\n"+$7->getname(),"stmnt");
	  }
	  | IF LPAREN expression RPAREN statement %prec LOWER_THAN_ELSE
	  {
	    	outlog<<"At line no: "<<lines<<" statement : IF LPAREN expression RPAREN statement "<<endl<<endl;
			outlog<<"if("<<$3->getname()<<")\n"<<$5->getname()<<endl<<endl;
			
			$$ = new symbol_info("if("+$3->getname()+")\n"+$5->getname(),"stmnt");
	  }
	  | IF LPAREN expression RPAREN statement ELSE statement
	  {
	    	outlog<<"At line no: "<<lines<<" statement : IF LPAREN expression RPAREN statement ELSE statement "<<endl<<endl;
			outlog<<"if("<<$3->getname()<<")\n"<<$5->getname()<<"\nelse\n"<<$7->getname()<<endl<<endl;
			
			$$ = new symbol_info("if("+$3->getname()+")\n"+$5->getname()+"\nelse\n"+$7->getname(),"stmnt");
	  }
	  | WHILE LPAREN expression RPAREN statement
	  {
	    	outlog<<"At line no: "<<lines<<" statement : WHILE LPAREN expression RPAREN statement "<<endl<<endl;
			outlog<<"while("<<$3->getname()<<")\n"<<$5->getname()<<endl<<endl;
			
			$$ = new symbol_info("while("+$3->getname()+")\n"+$5->getname(),"stmnt");
	  }
	  | PRINTLN LPAREN ID RPAREN SEMICOLON
	  {
	    	outlog<<"At line no: "<<lines<<" statement : PRINTLN LPAREN ID RPAREN SEMICOLON "<<endl<<endl;
			outlog<<"printf("<<$3->getname()<<");"<<endl<<endl; 
			
			$$ = new symbol_info("printf("+$3->getname()+");","stmnt");
			
			// Check if variable is declared
			symbol_info temp_symbol($3->getname(), "ID");
			symbol_info* looked = symtab->lookup(&temp_symbol);
			if (looked == NULL) {
				outerr << "At line no: " << lines << " Undeclared variable " << $3->getname() << endl << endl;
				error_count++;
			}
	  }
	  | RETURN expression SEMICOLON
	  {
	    	outlog<<"At line no: "<<lines<<" statement : RETURN expression SEMICOLON "<<endl<<endl;
			outlog<<"return "<<$2->getname()<<";"<<endl<<endl;
			
			$$ = new symbol_info("return "+$2->getname()+";","stmnt");
	  }
	  ;
	  
expression_statement : SEMICOLON
			{
				outlog<<"At line no: "<<lines<<" expression_statement : SEMICOLON "<<endl<<endl;
				outlog<<";"<<endl<<endl;
				
				$$ = new symbol_info(";","expr_stmt");
	        }			
			| expression SEMICOLON 
			{
				outlog<<"At line no: "<<lines<<" expression_statement : expression SEMICOLON "<<endl<<endl;
				outlog<<$1->getname()<<";"<<endl<<endl;
				
				$$ = new symbol_info($1->getname()+";","expr_stmt");
	        }
			;
	  
variable : ID 	
      {
	    outlog<<"At line no: "<<lines<<" variable : ID "<<endl<<endl;
		outlog<<$1->getname()<<endl<<endl;
			
		$$ = new symbol_info($1->getname(),"varbl");
		
		// Lookup variable in symbol table
		symbol_info temp_symbol($1->getname(), "ID");
		symbol_info* looked = symtab->lookup(&temp_symbol);
		if (looked == NULL) {
			outerr << "At line no: " << lines << " Undeclared variable " << $1->getname() << endl << endl;
			error_count++;
			$$->set_data_type("");
		} else if (looked->is_array()) {
			outerr << "At line no: " << lines << " variable is of array type : " << $1->getname() << endl << endl;
			outlog << "At line no: " << lines << " variable is of array type : " << $1->getname() << endl << endl;
			error_count++;
			$$->set_data_type(""); // Suppress further type errors
		} else {
			$$->set_data_type(looked->get_data_type());
		}
	 }	
	 | ID LTHIRD expression RTHIRD 
	 {
	 	outlog<<"At line no: "<<lines<<" variable : ID LTHIRD expression RTHIRD "<<endl<<endl;
		outlog<<$1->getname()<<"["<<$3->getname()<<"]"<<endl<<endl;
		
		$$ = new symbol_info($1->getname()+"["+$3->getname()+"]","varbl");
		
		// Lookup array variable in symbol table
		symbol_info temp_symbol($1->getname(), "ID");
		symbol_info* looked = symtab->lookup(&temp_symbol);
		if (looked == NULL) {
			outerr << "At line no: " << lines << " Undeclared variable " << $1->getname() << endl << endl;
			error_count++;
			$$->set_data_type("");
		} else if (!looked->is_array()) {
			outerr << "At line no: " << lines << " variable is not of array type : " << $1->getname() << endl << endl;
			error_count++;
			$$->set_data_type("");
		} else {
			// Check array index type
			if ($3->get_data_type() != "int" && $3->get_data_type() != "") {
				outerr << "At line no: " << lines << " array index is not of integer type : " << $1->getname() << endl << endl;
				outlog << "At line no: " << lines << " array index is not of integer type : " << $1->getname() << endl << endl;
				error_count++;
			}
			$$->set_data_type(looked->get_data_type());
		}
	 }
	 ;
	 
expression : logic_expression
	   {
	    	outlog<<"At line no: "<<lines<<" expression : logic_expression "<<endl<<endl;
			outlog<<$1->getname()<<endl<<endl;
			
			$$ = new symbol_info($1->getname(),"expr");
			$$->set_data_type($1->get_data_type());
	   }
	   | variable ASSIGNOP logic_expression 	
	   {
	    	outlog<<"At line no: "<<lines<<" expression : variable ASSIGNOP logic_expression "<<endl<<endl;
			outlog<<$1->getname()<<"="<<$3->getname()<<endl<<endl;

			$$ = new symbol_info($1->getname()+"="+$3->getname(),"expr");
			
			// Type checking for assignment
			string var_type = $1->get_data_type();
			string expr_type = $3->get_data_type();
			
			// Check for void operation
			if (expr_type == "void") {
				outerr << "At line no: " << lines << " operation on void type " << endl << endl;
				error_count++;
			} else if (expr_type != "" && var_type != "" && var_type != expr_type) {
							if (var_type == "int" && expr_type == "float") {
				outerr << "At line no: " << lines << " Warning: Assignment of float value into variable of integer type " << endl << endl;
				outlog << "At line no: " << lines << " Warning: Assignment of float value into variable of integer type " << endl << endl;
				error_count++;
				} else {
					outerr << "At line no: " << lines << " Operands of assignment operator are not consistent " << endl << endl;
					error_count++;
				}
			}
			
			// Set result type to variable type or expression type
			if (var_type != "") {
				$$->set_data_type(var_type);
			} else {
				$$->set_data_type(expr_type);
			}
	   }
	   ;
			
logic_expression : rel_expression
	     {
	    	outlog<<"At line no: "<<lines<<" logic_expression : rel_expression "<<endl<<endl;
			outlog<<$1->getname()<<endl<<endl;
			
			$$ = new symbol_info($1->getname(),"lgc_expr");
			$$->set_data_type($1->get_data_type());
	     }	
		 | rel_expression LOGICOP rel_expression 
		 {
	    	outlog<<"At line no: "<<lines<<" logic_expression : rel_expression LOGICOP rel_expression "<<endl<<endl;
			outlog<<$1->getname()<<$2->getname()<<$3->getname()<<endl<<endl;
			
			$$ = new symbol_info($1->getname()+$2->getname()+$3->getname(),"lgc_expr");
			$$->set_data_type("int"); // LOGICOP results are always int
	     }	
		 ;
			
rel_expression	: simple_expression
		{
	    	outlog<<"At line no: "<<lines<<" rel_expression : simple_expression "<<endl<<endl;
			outlog<<$1->getname()<<endl<<endl;
			
			$$ = new symbol_info($1->getname(),"rel_expr");
			$$->set_data_type($1->get_data_type());
		}
			| simple_expression RELOP simple_expression
		{
	    	outlog<<"At line no: "<<lines<<" rel_expression : simple_expression RELOP simple_expression "<<endl<<endl;
			outlog<<$1->getname()<<$2->getname()<<$3->getname()<<endl<<endl;
			
			$$ = new symbol_info($1->getname()+$2->getname()+$3->getname(),"rel_expr");
			$$->set_data_type("int"); // RELOP results are always int
		}
		;
				
simple_expression : term
          {
	    	outlog<<"At line no: "<<lines<<" simple_expression : term "<<endl<<endl;
			outlog<<$1->getname()<<endl<<endl;
			
			$$ = new symbol_info($1->getname(),"simp_expr");
			$$->set_data_type($1->get_data_type());
	      }
		  	  | simple_expression ADDOP term 
		  {
	    	outlog<<"At line no: "<<lines<<" simple_expression : simple_expression ADDOP term "<<endl<<endl;
			outlog<<$1->getname()<<$2->getname()<<$3->getname()<<endl<<endl;
			
			$$ = new symbol_info($1->getname()+$2->getname()+$3->getname(),"simp_expr");
			
			string lt = $1->get_data_type();
			string rt = $3->get_data_type();
			
			// Check for void operands
			if (lt == "void" || rt == "void") {
				outerr << "At line no: " << lines << " operation on void type " << endl << endl;
				error_count++;
				$$->set_data_type("");
			} else {
				// Determine result type: float if any operand is float, else int
				if (lt == "float" || rt == "float") {
					$$->set_data_type("float");
				} else {
					$$->set_data_type("int");
				}
			}
		  }
		  ;
					
term :	unary_expression //term can be void because of un_expr->factor
     {
	    	outlog<<"At line no: "<<lines<<" term : unary_expression "<<endl<<endl;
			outlog<<$1->getname()<<endl<<endl;
			
			$$ = new symbol_info($1->getname(),"term");
			$$->set_data_type($1->get_data_type());
	 }
     |  term MULOP unary_expression
     {
	    	outlog<<"At line no: "<<lines<<" term : term MULOP unary_expression "<<endl<<endl;
			outlog<<$1->getname()<<$2->getname()<<$3->getname()<<endl<<endl;
			
			$$ = new symbol_info($1->getname()+$2->getname()+$3->getname(),"term");
			
			string lt = $1->get_data_type();
			string rt = $3->get_data_type();
			string op = $2->getname();
			
			// Check for void operands
			if (lt == "void" || rt == "void") {
				outerr << "At line no: " << lines << " operation on void type " << endl << endl;
				error_count++;
				$$->set_data_type("");
			} else if (op == "%") {
				// Modulus operator checks
				if (lt != "int" || rt != "int") {
					outerr << "At line no: " << lines << " Modulus operator on non integer type " << endl << endl;
					outlog << "At line no: " << lines << " Modulus operator on non integer type " << endl << endl;
					error_count++;
				}
				if ($3->getname() == "0") {
					outerr << "At line no: " << lines << " Modulus by 0 " << endl << endl;
					error_count++;
				}
				$$->set_data_type("int");
			} else if (op == "/") {
				// Division by zero check
				if ($3->getname() == "0") {
					outerr << "At line no: " << lines << " Division by 0 " << endl << endl;
					error_count++;
				}
				// Result type: float if any operand is float, else int
				if (lt == "float" || rt == "float") {
					$$->set_data_type("float");
				} else {
					$$->set_data_type("int");
				}
			} else {
				// Multiplication: float if any operand is float, else int
				if (lt == "float" || rt == "float") {
					$$->set_data_type("float");
				} else {
					$$->set_data_type("int");
				}
			}
	 }
     ;

unary_expression : ADDOP unary_expression  // un_expr can be void because of factor
		 {
	    	outlog<<"At line no: "<<lines<<" unary_expression : ADDOP unary_expression "<<endl<<endl;
			outlog<<$1->getname()<<$2->getname()<<endl<<endl;
			
			$$ = new symbol_info($1->getname()+$2->getname(),"un_expr");
			$$->set_data_type($2->get_data_type());
	     }
		 | NOT unary_expression 
		 {
	    	outlog<<"At line no: "<<lines<<" unary_expression : NOT unary_expression "<<endl<<endl;
			outlog<<"!"<<$2->getname()<<endl<<endl;
			
			$$ = new symbol_info("!"+$2->getname(),"un_expr");
			$$->set_data_type("int"); // NOT results in int
	     }
		 | factor 
		 {
	    	outlog<<"At line no: "<<lines<<" unary_expression : factor "<<endl<<endl;
			outlog<<$1->getname()<<endl<<endl;
			
			$$ = new symbol_info($1->getname(),"un_expr");
			$$->set_data_type($1->get_data_type());
	     }
		 ;
	
factor	: variable
    {
	    outlog<<"At line no: "<<lines<<" factor : variable "<<endl<<endl;
		outlog<<$1->getname()<<endl<<endl;
			
		$$ = new symbol_info($1->getname(),"fctr");
		$$->set_data_type($1->get_data_type());
	}
	| ID LPAREN argument_list RPAREN
	{
	    outlog<<"At line no: "<<lines<<" factor : ID LPAREN argument_list RPAREN "<<endl<<endl;
		outlog<<$1->getname()<<"("<<$3->getname()<<")"<<endl<<endl;

		$$ = new symbol_info($1->getname()+"("+$3->getname()+")","fctr");
		
		// Function call checking
		symbol_info temp_symbol($1->getname(), "ID");
		symbol_info* f = symtab->lookup(&temp_symbol);
		if (f == NULL) {
			outerr << "At line no: " << lines << " Undeclared function: " << $1->getname() << endl << endl;
			error_count++;
			$$->set_data_type("");
		} else if (!f->is_function()) {
			outerr << "At line no: " << lines << " A function call cannot be made with non-function type identifier." << endl << endl;
			error_count++;
			$$->set_data_type("");
		} else {
			// Check argument count and types
			vector<string> def_types = f->get_param_types();
			vector<string> call_types = $3->get_param_types();
			
			if (def_types.size() != call_types.size()) {
				outerr << "At line no: " << lines << " Inconsistencies in number of arguments in function call: " << $1->getname() << endl << endl;
				error_count++;
			} else {
				// Check each argument type
				for (int i = 0; i < def_types.size(); i++) {
					if (def_types[i] != call_types[i] && call_types[i] != "") {
						outerr << "At line no: " << lines << " argument " << (i+1) << " type mismatch in function call: " << $1->getname() << endl << endl;
						error_count++;
					}
				}
			}
			$$->set_data_type(f->get_return_type());
		}
	}
	| LPAREN expression RPAREN
	{
	   	outlog<<"At line no: "<<lines<<" factor : LPAREN expression RPAREN "<<endl<<endl;
		outlog<<"("<<$2->getname()<<")"<<endl<<endl;
		
		$$ = new symbol_info("("+$2->getname()+")","fctr");
		$$->set_data_type($2->get_data_type());
	}
	| CONST_INT 
	{
	    outlog<<"At line no: "<<lines<<" factor : CONST_INT "<<endl<<endl;
		outlog<<$1->getname()<<endl<<endl;
			
		$$ = new symbol_info($1->getname(),"fctr");
		$$->set_data_type("int");
	}
	| CONST_FLOAT
	{
	    outlog<<"At line no: "<<lines<<" factor : CONST_FLOAT "<<endl<<endl;
		outlog<<$1->getname()<<endl<<endl;
			
		$$ = new symbol_info($1->getname(),"fctr");
		$$->set_data_type("float");
	}
	| variable INCOP 
	{
	    outlog<<"At line no: "<<lines<<" factor : variable INCOP "<<endl<<endl;
		outlog<<$1->getname()<<"++"<<endl<<endl;
			
		$$ = new symbol_info($1->getname()+"++","fctr");
		$$->set_data_type($1->get_data_type());
	}
	| variable DECOP
	{
	    outlog<<"At line no: "<<lines<<" factor : variable DECOP "<<endl<<endl;
		outlog<<$1->getname()<<"--"<<endl<<endl;
			
		$$ = new symbol_info($1->getname()+"--","fctr");
		$$->set_data_type($1->get_data_type());
	}
	;
	
argument_list : arguments
			  {
					outlog<<"At line no: "<<lines<<" argument_list : arguments "<<endl<<endl;
					outlog<<$1->getname()<<endl<<endl;
						
					$$ = new symbol_info($1->getname(),"arg_list");
					$$->set_param_types($1->get_param_types());
			  }
			  |
			  {
					outlog<<"At line no: "<<lines<<" argument_list :  "<<endl<<endl;
					outlog<<""<<endl<<endl;
						
					$$ = new symbol_info("","arg_list");
					vector<string> empty_params;
					$$->set_param_types(empty_params);
			  }
			  ;
	
arguments : arguments COMMA logic_expression
		  {
				outlog<<"At line no: "<<lines<<" arguments : arguments COMMA logic_expression "<<endl<<endl;
				outlog<<$1->getname()<<","<<$3->getname()<<endl<<endl;
						
				$$ = new symbol_info($1->getname()+","+$3->getname(),"arg");
				
				// Collect parameter types
				vector<string> param_types = $1->get_param_types();
				param_types.push_back($3->get_data_type());
				$$->set_param_types(param_types);
		  }
	      	      | logic_expression
	      {
				outlog<<"At line no: "<<lines<<" arguments : logic_expression "<<endl<<endl;
				outlog<<$1->getname()<<endl<<endl;
						
				$$ = new symbol_info($1->getname(),"arg");
				
				// Single argument - create vector with one type
				vector<string> param_types;
				param_types.push_back($1->get_data_type());
				$$->set_param_types(param_types);
	      }
	      ;
 

%%

int main(int argc, char *argv[])
{
	if(argc != 2) 
	{
		cout<<"Please input file name"<<endl;
		return 0;
	}
	yyin = fopen(argv[1], "r");
	outlog.open("24141083_24141100_log1.txt", ios::trunc);
	outerr.open("24141083_24141100_error.txt", ios::trunc);
	
	if(yyin == NULL)
	{
		cout<<"Couldn't open file"<<endl;
		return 0;
	}
	
	// Initialize symbol table with 11 buckets
	symtab = new symbol_table(11);
	outlog << "New ScopeTable with ID " << symtab->get_current_scope_id() << " created" << endl << endl;

	yyparse();
	
	outlog<<endl<<"Total lines: "<<lines<<endl;
	outlog<<"Total errors: "<<error_count<<endl;
	outerr<<"Total errors: "<<error_count<<endl;
	
	// Clean up
	delete symtab;
	
	outlog.close();
	outerr.close();
	
	fclose(yyin);
	
	return 0;
}